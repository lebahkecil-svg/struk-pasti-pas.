# Struk Pasti Pas — Aplikasi Android Native (Kotlin)

Konversi dari versi HTML/PWA ke aplikasi **Android native** (Kotlin + Jetpack Compose, bukan WebView).
Tampilan form dan struk sama dengan versi HTML, dan bisa mencetak langsung ke printer thermal lewat
**Bluetooth**, **kabel USB (OTG)**, atau **WiFi** — tanpa aplikasi tambahan (RawBT tidak diperlukan lagi).

## Build APK lewat GitHub

1. Buat repository baru di GitHub, lalu upload **seluruh isi folder ini** (termasuk folder tersembunyi `.github`).
   Cara paling aman memakai Git / GitHub Desktop:
   ```bash
   git init
   git add .
   git commit -m "Struk Pasti Pas"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```
2. Buka tab **Actions** → workflow **Build APK** akan jalan otomatis (atau klik **Run workflow**).
3. Setelah hijau (± 4–6 menit), buka run tersebut → bagian **Artifacts** → unduh **StrukPastiPas-APK**.
4. Ekstrak zip-nya, kirim `StrukPastiPas.apk` ke HP, lalu install (izinkan "Install dari sumber tidak dikenal").

Mau APK muncul di halaman **Releases**? Cukup beri tag:
```bash
git tag v1.0.0
git push origin v1.0.0
```

## Cara mencetak

Pilih koneksi di bagian **Koneksi Printer Thermal** (bawah form), pilih lebar kertas, lalu tekan **Cetak**.

| Koneksi | Langkah |
|---|---|
| **Bluetooth** | Pair printer dulu di Pengaturan Bluetooth Android (PIN umumnya `0000`/`1234`). Di aplikasi: **Pilih Printer Bluetooth** → pilih printer → **Cetak**. Pilihan printer diingat. |
| **USB** | Sambungkan printer ke HP dengan kabel USB/OTG, nyalakan printer, tekan **Cari Printer USB**, lalu **Cetak**. Izinkan akses USB saat diminta. |
| **WiFi** | Isi alamat IP printer (port standar `9100`), HP & printer harus satu jaringan. |

**Mode cetak**
- **Gambar** (default): struk digambar sebagai bitmap lalu dikirim ke printer → hasil cetak *sama persis* dengan pratinjau (termasuk logo Pertamina).
- **Teks**: memakai font bawaan printer, lebih cepat; format sama dengan mode RawBT di versi HTML.

**Lebar kertas**: 80 mm (576 dot) atau 58 mm (384 dot). Tampilan struk otomatis diskalakan.

Tombol **Cetak via Layanan Cetak Android** setara tombol "Cetak (Browser/PWA)" di versi HTML: untuk simpan PDF atau printer biasa
yang terpasang di Android.

## Kustomisasi

| Yang ingin diubah | File |
|---|---|
| Daftar operator, jenis BBM, harga bawaan, jenis yang disubsidi | `app/src/main/java/com/spbu/strukpastipas/Model.kt` (`object Config`) |
| Isi/format struk | `Receipt.kt` |
| Ukuran & tata letak struk (lebar label, font, margin) | `ReceiptRenderer.kt` |
| Ketebalan hasil cetak (ambang hitam-putih) | `EscPos.kt` → `THRESHOLD` (naik = lebih tebal/gelap) |
| Jumlah feed kertas sebelum dipotong | `EscPos.kt` → `FEED_LINES` |
| Nama aplikasi | `app/src/main/res/values/strings.xml` |
| ID aplikasi / versi | `app/build.gradle.kts` |
| Logo & ikon | `app/src/main/res/drawable-nodpi/pertamina_logo.png`, `mipmap-*/ic_launcher.png` |

## Troubleshooting

- **Bluetooth gagal terhubung** — pastikan printer menyala, sudah di-pair, dan tidak sedang tersambung ke HP lain. Pilih ulang printer.
- **USB tidak terdeteksi** — coba kabel/adaptor OTG lain; sebagian HP perlu mengaktifkan "OTG" di pengaturan.
- **Hasil cetak terlalu terang/tipis** — naikkan `THRESHOLD` di `EscPos.kt` (mis. 190), atau pakai mode **Teks**.
- **Printer mencetak karakter acak (mode Gambar)** — printer tidak mendukung perintah raster `GS v 0`; gunakan mode **Teks**.
- **Kertas tidak terpotong** — printer tanpa auto-cutter mengabaikan perintah potong; ini normal.

## Struktur

```
.github/workflows/build-apk.yml   ← build otomatis di GitHub Actions
app/src/main/java/com/spbu/strukpastipas/
  MainActivity.kt        titik masuk
  StrukScreen.kt         layar form + pratinjau + panel cetak (Compose)
  Components.kt, Theme.kt  komponen & warna
  MainViewModel.kt       state form, hitung volume↔nominal, simpan harga, alur cetak
  Model.kt, Receipt.kt   konfigurasi, format angka, isi struk (gambar & teks)
  ReceiptRenderer.kt     menggambar struk → Bitmap (dipakai pratinjau & cetak)
  EscPos.kt              perintah ESC/POS (raster & teks)
  Printing.kt            koneksi Bluetooth / USB / WiFi
```

Membuka di Android Studio: **File → Open** folder ini (Android Studio Koala atau lebih baru; pakai Gradle 8.9 bila diminta).
