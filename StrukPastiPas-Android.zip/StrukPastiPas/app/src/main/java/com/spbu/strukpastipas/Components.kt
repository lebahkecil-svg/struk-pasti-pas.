package com.spbu.strukpastipas

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Judul seksi (setara <h2>): teks biru tebal dengan garis bawah 2px. */
@Composable
fun SectionTitle(text: String, first: Boolean = false) {
    Column(Modifier.fillMaxWidth().padding(top = if (first) 0.dp else 22.dp)) {
        Text(
            text,
            color = Accent,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Box(Modifier.fillMaxWidth().height(2.dp).background(Accent))
    }
}

@Composable
fun FieldLabel(text: String) {
    Text(
        text,
        color = LabelColor,
        fontSize = 12.sp,
        modifier = Modifier.padding(top = 10.dp, bottom = 3.dp)
    )
}

@Composable
fun Note(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = NoteColor,
        fontSize = 10.5.sp,
        lineHeight = 14.sp,
        modifier = modifier.padding(top = 2.dp)
    )
}

@Composable
fun FormInput(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    placeholder: String = "",
    fontSize: TextUnit = 13.sp,
    padding: PaddingValues = PaddingValues(horizontal = 8.dp, vertical = 7.dp)
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(5.dp)
    val locked = !enabled || readOnly
    val bg = if (locked) FieldDisabledBg else Color.White
    val textColor = if (locked) Color(0xFF555555) else Color(0xFF222222)

    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        enabled = enabled,
        readOnly = readOnly,
        singleLine = true,
        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = fontSize, color = textColor),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        cursorBrush = SolidColor(Accent),
        modifier = modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(bg, shape)
                    .border(1.dp, if (focused && !locked) Accent else FieldBorder, shape)
                    .padding(padding)
            ) {
                if (value.isEmpty() && placeholder.isNotEmpty()) {
                    Text(
                        placeholder,
                        color = Color(0xFF999999),
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize
                    )
                }
                inner()
            }
        }
    )
}

@Composable
fun FormDropdown(
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(5.dp)
    Box(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color.White, shape)
                .border(1.dp, FieldBorder, shape)
                .clip(shape)
                .clickable { expanded = true }
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                value,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color(0xFF222222),
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            Text("▾", color = LabelColor, fontSize = 12.sp)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                    onClick = {
                        onSelect(opt)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    secondary: Boolean = false,
    enabled: Boolean = true,
    fontSize: TextUnit = 14.sp,
    vPad: Dp = 12.dp
) {
    val shape = RoundedCornerShape(6.dp)
    val bg = if (secondary) SecondaryBg else Accent
    val fg = if (secondary) Accent else Color.White
    Box(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.6f)
            .clip(shape)
            .background(bg)
            .then(if (secondary) Modifier.border(1.dp, Accent, shape) else Modifier)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = vPad),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) Accent else SecondaryBg)
            .border(1.dp, Accent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) Color.White else Accent,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}
