package com.spbu.strukpastipas

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ConnType { BLUETOOTH, USB, WIFI }
enum class PrintMode { IMAGE, TEXT }

data class PriceDraft(val non: String, val sub: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs: SharedPreferences = app.getSharedPreferences("struk_prefs", Context.MODE_PRIVATE)

    /* ----------------------------- FORM ----------------------------- */
    var kodeSpbu by mutableStateOf("31.107.02")
    var namaSpbu by mutableStateOf("SPBU Samanhudi")
    var alamat by mutableStateOf("Jl. Samanhudi No. 20")

    var shift by mutableStateOf("2")
    var noTrans by mutableStateOf("939468")
    var waktu by mutableStateOf(formatWaktuNow())

    var pulauPompa by mutableStateOf("4")
    var operatorName by mutableStateOf("RANGGA ADITIA")
    var jenisBBM by mutableStateOf("PERTALITE")
    var volume by mutableStateOf("10.000")
    var nominal by mutableStateOf("100000")

    var plat by mutableStateOf("B2886UZF")
    var odometer by mutableStateOf("")

    /* ------------------------- HARGA BBM (tersimpan) ------------------------- */
    var prices by mutableStateOf(loadPrices())
        private set
    var editingPrices by mutableStateOf(false)
        private set
    var priceDraft by mutableStateOf<Map<String, PriceDraft>>(emptyMap())
        private set
    var priceSaved by mutableStateOf(false)
        private set

    val hargaNonSubsidi: Double get() = prices[jenisBBM]?.nonSubsidi ?: 0.0
    val subsidiLiter: Double get() = prices[jenisBBM]?.subsidi ?: 0.0
    val hargaJual: Double get() = maxOf(0.0, hargaNonSubsidi - subsidiLiter)

    /* ------------------------- PENGATURAN PRINTER ------------------------- */
    var connType by mutableStateOf(enumOr(prefs.getString("conn", null), ConnType.BLUETOOTH))
        private set
    var printMode by mutableStateOf(enumOr(prefs.getString("mode", null), PrintMode.IMAGE))
        private set
    var paperMm by mutableStateOf(prefs.getInt("paper_mm", 80))
        private set
    var btName by mutableStateOf(prefs.getString("bt_name", "") ?: "")
        private set
    var btAddress by mutableStateOf(prefs.getString("bt_addr", "") ?: "")
        private set
    var wifiHost by mutableStateOf(prefs.getString("wifi_host", "") ?: "")
        private set
    var wifiPort by mutableStateOf(prefs.getString("wifi_port", "9100") ?: "9100")
        private set

    var btDevices by mutableStateOf<List<BtDevice>>(emptyList())
        private set
    var usbLabels by mutableStateOf<List<String>>(emptyList())
        private set

    var printing by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var statusError by mutableStateOf(false)
        private set

    init {
        syncFromVolume()
    }

    /* ------------------------- Sinkron Volume <-> Nominal ------------------------- */
    private fun syncFromVolume() {
        val v = volume.toDoubleOrNull() ?: 0.0
        nominal = jsRound(v * hargaJual).toString()
    }

    private fun syncFromNominal() {
        val n = nominal.toDoubleOrNull() ?: 0.0
        val hj = hargaJual
        volume = fmtVolume(if (hj > 0) n / hj else 0.0)
    }

    fun onVolumeChange(s: String) {
        volume = s.filter { it.isDigit() || it == '.' }
        syncFromVolume()
    }

    fun onNominalChange(s: String) {
        nominal = s.filter { it.isDigit() || it == '.' }
        syncFromNominal()
    }

    fun onJenisChange(j: String) {
        jenisBBM = j
        syncFromVolume()
    }

    /* ------------------------- Pengaturan harga ------------------------- */
    private fun loadPrices(): Map<String, Price> {
        val out = LinkedHashMap<String, Price>()
        for (j in Config.JENIS_LIST) {
            val def = Config.DEFAULT_PRICES[j] ?: Price(0.0, 0.0)
            val non = prefs.getString("price_non_$j", null)?.toDoubleOrNull() ?: def.nonSubsidi
            val sub = prefs.getString("price_sub_$j", null)?.toDoubleOrNull() ?: def.subsidi
            out[j] = Price(non, sub)
        }
        return out
    }

    fun startEditPrices() {
        priceDraft = prices.mapValues { PriceDraft(numStr(it.value.nonSubsidi), numStr(it.value.subsidi)) }
        editingPrices = true
        priceSaved = false
    }

    fun onDraftChange(jenis: String, non: String? = null, sub: String? = null) {
        val cur = priceDraft[jenis] ?: PriceDraft("", "")
        val clean = { t: String -> t.filter { c -> c.isDigit() || c == '.' } }
        val next = PriceDraft(non?.let(clean) ?: cur.non, sub?.let(clean) ?: cur.sub)
        priceDraft = priceDraft + (jenis to next)
    }

    fun savePrices() {
        val result = LinkedHashMap<String, Price>()
        val ed = prefs.edit()
        for (j in Config.JENIS_LIST) {
            val d = priceDraft[j]
            val p = Price(d?.non?.toDoubleOrNull() ?: 0.0, d?.sub?.toDoubleOrNull() ?: 0.0)
            result[j] = p
            ed.putString("price_non_$j", numStr(p.nonSubsidi))
            ed.putString("price_sub_$j", numStr(p.subsidi))
        }
        ed.apply()
        prices = result
        editingPrices = false
        priceSaved = true
    }

    /* ------------------------- Setelan printer ------------------------- */
    fun updateConnType(t: ConnType) {
        connType = t
        prefs.edit().putString("conn", t.name).apply()
    }

    fun updatePrintMode(m: PrintMode) {
        printMode = m
        prefs.edit().putString("mode", m.name).apply()
    }

    fun updatePaperMm(mm: Int) {
        paperMm = mm
        prefs.edit().putInt("paper_mm", mm).apply()
    }

    fun updateWifiHost(h: String) {
        wifiHost = h.trim()
        prefs.edit().putString("wifi_host", wifiHost).apply()
    }

    fun updateWifiPort(p: String) {
        wifiPort = p.filter { it.isDigit() }
        prefs.edit().putString("wifi_port", wifiPort).apply()
    }

    fun selectBt(d: BtDevice) {
        btName = d.name
        btAddress = d.address
        prefs.edit().putString("bt_name", d.name).putString("bt_addr", d.address).apply()
    }

    fun loadBtDevices() {
        btDevices = Printing.bondedBluetoothDevices(getApplication<Application>())
    }

    fun scanUsb() {
        usbLabels = Printing.usbCandidates(getApplication<Application>()).map { Printing.usbLabel(it) }
    }

    fun setStatus(msg: String, error: Boolean) {
        status = msg
        statusError = error
    }

    /* ------------------------- Data struk ------------------------- */
    fun receiptInput(): ReceiptInput = ReceiptInput(
        kodeSpbu = kodeSpbu,
        namaSpbu = namaSpbu,
        alamat = alamat,
        shift = shift,
        noTrans = noTrans,
        waktu = waktu,
        pulauPompa = pulauPompa,
        operatorName = operatorName,
        jenisBBM = jenisBBM,
        volume = volume.toDoubleOrNull() ?: 0.0,
        hargaNonSubsidi = hargaNonSubsidi,
        subsidiLiter = subsidiLiter,
        hargaJual = hargaJual,
        plat = plat.trim(),
        odometer = odometer.trim()
    )

    /* ------------------------- Cetak ------------------------- */
    fun print() {
        if (printing) return
        val app = getApplication<Application>()
        val input = receiptInput()
        val type = connType
        val mode = printMode
        val dots = if (paperMm == 58) 384 else 576
        val btAddr = btAddress
        val host = wifiHost
        val portText = wifiPort

        viewModelScope.launch {
            printing = true
            setStatus("Menyiapkan struk…", false)
            try {
                when (type) {
                    ConnType.BLUETOOTH -> if (btAddr.isBlank()) throw PrintException("Pilih printer Bluetooth terlebih dulu.")
                    ConnType.WIFI -> if (host.isBlank()) throw PrintException("Isi alamat IP printer WiFi terlebih dulu.")
                    ConnType.USB -> Unit
                }
                val data = withContext(Dispatchers.Default) {
                    if (mode == PrintMode.IMAGE) {
                        val bmp = ReceiptRenderer.render(app, buildReceiptLines(input), dots)
                        EscPos.imageJob(bmp)
                    } else {
                        EscPos.textJob(buildReceiptText(input))
                    }
                }
                setStatus("Mengirim ke printer…", false)
                when (type) {
                    ConnType.BLUETOOTH -> Printing.sendBluetooth(app, btAddr, data)
                    ConnType.USB -> Printing.sendUsb(app, data)
                    ConnType.WIFI -> {
                        val port = portText.toIntOrNull() ?: 9100
                        Printing.sendWifi(host, port, data)
                    }
                }
                setStatus("✅ Struk terkirim ke printer.", false)
            } catch (e: PrintException) {
                setStatus("⚠️ " + (e.message ?: "Gagal mencetak."), true)
            } catch (e: SecurityException) {
                setStatus("⚠️ Izin ditolak: " + (e.message ?: "periksa izin aplikasi."), true)
            } catch (e: Exception) {
                setStatus("⚠️ Gagal mencetak: " + (e.message ?: e.javaClass.simpleName), true)
            } finally {
                printing = false
            }
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
        try {
            if (name == null) default else enumValueOf<T>(name)
        } catch (e: IllegalArgumentException) {
            default
        }
}
