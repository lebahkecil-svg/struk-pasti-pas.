package com.spbu.strukpastipas

/** Satu elemen pada struk. Dipakai bersama oleh pratinjau layar dan hasil cetak. */
sealed class RLine {
    object Logo : RLine()

    /** Garis putus-putus. */
    object Sep : RLine()

    /** Teks biasa (boleh wrap), rata tengah atau rata kiri. */
    data class Block(
        val text: String,
        val size: Float = 12.5f,
        val bold: Boolean = false,
        val center: Boolean = false,
        val mt: Float = 0f,
        val mb: Float = 0f
    ) : RLine()

    /** Baris "label : nilai". */
    data class Row(val label: String, val value: String) : RLine()

    /** Total (tebal, rata kanan). */
    data class Total(val value: String) : RLine()
}

fun buildReceiptLines(r: ReceiptInput): List<RLine> = buildList {
    add(RLine.Logo)
    add(RLine.Block(r.kodeSpbu, size = 19f, bold = true, center = true, mt = 10f, mb = 2f))
    add(RLine.Block(r.namaSpbu, center = true))
    add(RLine.Block(r.alamat, center = true))
    add(RLine.Sep)
    add(RLine.Row("Shift", r.shift + "  No. Trans : " + r.noTrans))
    add(RLine.Row("Wakt.", r.waktu))
    add(RLine.Sep)

    if (r.subsidi) {
        // ===== STRUK PANJANG (SUBSIDI) =====
        add(RLine.Row("Pulau/Pompa", r.pulauPompa))
        add(RLine.Row("Operator", r.operatorName))
        add(RLine.Row("Jenis BBM", r.jenisBBM))
        add(RLine.Row("Volume", fmtVolume(r.volume) + " liter"))
        add(RLine.Sep)
        add(RLine.Block("Informasi Harga BBM (Rp/Liter)"))
        add(RLine.Row("Harga Non Subsidi", fmtRupiah(r.hargaNonSubsidi)))
        add(RLine.Row("Subsidi Pemerintah", fmtRupiah(r.subsidiLiter)))
        add(RLine.Row("Harga Jual", fmtRupiah(r.hargaJual)))
        add(RLine.Sep)
        add(RLine.Block("Total Penjualan (Rp)"))
        add(RLine.Row("Tanpa Subsidi", fmtRupiah(r.totalTanpaSubsidi)))
        add(RLine.Row("Subsidi Pemerintah", fmtRupiah(r.totalSubsidi)))
        add(RLine.Row("Dibayar Konsumen", fmtRupiah(r.totalDibayar)))
        add(RLine.Sep)
        add(RLine.Block("CASH"))
        add(RLine.Total(fmtRupiah(r.totalDibayar)))
        add(RLine.Sep)
        add(RLine.Row("No. Plat", r.plat.ifEmpty { "-" }))
        add(RLine.Row("Odometer", r.odometer.ifEmpty { "-" }))
        add(RLine.Sep)
        add(
            RLine.Block(
                "Anda mendapat subsidi dari Pemerintah sebesar Rp " + fmtRupiah(r.totalSubsidi) +
                    " (Perhitungan Subsidi Unaudited atau Estimasi). Gunakan BBM Subsidi secara bijak.",
                size = 11f,
                mt = 10f
            )
        )
    } else {
        // ===== STRUK PENDEK (NON SUBSIDI) =====
        add(RLine.Row("Pulau/Pompa", r.pulauPompa))
        add(RLine.Row("Nama Produk", r.jenisBBM.replace(Regex("\\s+"), "_")))
        add(RLine.Row("Harga/Liter", "Rp. " + fmtRupiah(r.hargaJual)))
        add(RLine.Row("Volume", "(L) " + fmtVolume(r.volume)))
        add(RLine.Row("Total Harga", "Rp. " + fmtRupiah(r.totalDibayar)))
        add(RLine.Row("Operator", r.operatorName))
        add(RLine.Sep)
        add(RLine.Block("CASH"))
        add(RLine.Total(fmtRupiah(r.totalDibayar)))
        // Plat & Odometer hanya tercetak bila diisi
        if (r.plat.isNotEmpty()) add(RLine.Row("No. Plat", r.plat))
        if (r.odometer.isNotEmpty()) add(RLine.Row("Odometer", r.odometer))
    }
}

/* ======================================================================
 * Versi TEKS (ESC/POS mode teks) - port dari buildReceiptText() versi HTML
 * ====================================================================== */

private const val TEXT_WIDTH = 32
private const val DASHES = "------------------------------"

private fun textLine(label: String, value: String): String = label.padEnd(18, ' ') + ": " + value

private fun centerText(s: String): String {
    if (s.length >= TEXT_WIDTH) return s
    val padLeft = (TEXT_WIDTH - s.length) / 2
    return " ".repeat(padLeft) + s
}

fun buildReceiptText(r: ReceiptInput): String {
    val t = StringBuilder()
    t.append("        PERTAMINA\n")
    t.append("\n")
    t.append(centerText(r.kodeSpbu)).append("\n")
    t.append(centerText(r.namaSpbu)).append("\n")
    t.append(centerText(r.alamat)).append("\n")
    t.append(DASHES).append("\n")
    t.append(textLine("Shift", r.shift + "   No. Trans : " + r.noTrans)).append("\n")
    t.append(textLine("Wakt.", r.waktu)).append("\n")
    t.append(DASHES).append("\n")

    if (r.subsidi) {
        t.append(textLine("Pulau/Pompa", r.pulauPompa)).append("\n")
        t.append(textLine("Operator", r.operatorName)).append("\n")
        t.append(textLine("Jenis BBM", r.jenisBBM)).append("\n")
        t.append(textLine("Volume", fmtVolume(r.volume) + " liter")).append("\n")
        t.append(DASHES).append("\n")
        t.append("Informasi Harga BBM (Rp/Liter)\n")
        t.append(textLine("Harga Non Subsidi", fmtRupiah(r.hargaNonSubsidi))).append("\n")
        t.append(textLine("Subsidi Pemerintah", fmtRupiah(r.subsidiLiter))).append("\n")
        t.append(textLine("Harga Jual", fmtRupiah(r.hargaJual))).append("\n")
        t.append(DASHES).append("\n")
        t.append("Total Penjualan (Rp)\n")
        t.append(textLine("Tanpa Subsidi", fmtRupiah(r.totalTanpaSubsidi))).append("\n")
        t.append(textLine("Subsidi Pemerintah", fmtRupiah(r.totalSubsidi))).append("\n")
        t.append(textLine("Dibayar Konsumen", fmtRupiah(r.totalDibayar))).append("\n")
        t.append(DASHES).append("\n")
        t.append("CASH\n")
        t.append(fmtRupiah(r.totalDibayar)).append("\n")
        t.append(DASHES).append("\n")
        t.append(textLine("No. Plat", r.plat.ifEmpty { "-" })).append("\n")
        t.append(textLine("Odometer", r.odometer.ifEmpty { "-" })).append("\n")
        t.append(DASHES).append("\n")
        t.append("Anda mendapat subsidi dari Pemerintah\n")
        t.append("sebesar Rp ").append(fmtRupiah(r.totalSubsidi)).append("\n")
        t.append("(Perhitungan Subsidi Unaudited atau\n")
        t.append("Estimasi). Gunakan BBM Subsidi secara\n")
        t.append("bijak.\n")
    } else {
        t.append(textLine("Pulau/Pompa", r.pulauPompa)).append("\n")
        t.append(textLine("Nama Produk", r.jenisBBM.replace(Regex("\\s+"), "_"))).append("\n")
        t.append(textLine("Harga/Liter", "Rp. " + fmtRupiah(r.hargaJual))).append("\n")
        t.append(textLine("Volume", "(L) " + fmtVolume(r.volume))).append("\n")
        t.append(textLine("Total Harga", "Rp. " + fmtRupiah(r.totalDibayar))).append("\n")
        t.append(textLine("Operator", r.operatorName)).append("\n")
        t.append(DASHES).append("\n")
        t.append("CASH\n")
        t.append(fmtRupiah(r.totalDibayar)).append("\n")
        if (r.plat.isNotEmpty()) t.append(textLine("No. Plat", r.plat)).append("\n")
        if (r.odometer.isNotEmpty()) t.append(textLine("Odometer", r.odometer)).append("\n")
    }
    t.append("\n\n\n")
    return t.toString()
}
