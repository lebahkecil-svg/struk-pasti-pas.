package com.spbu.strukpastipas

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import kotlin.coroutines.resume

class PrintException(message: String) : Exception(message)

data class BtDevice(val name: String, val address: String)

object Printing {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private const val BT_CHUNK = 1024
    private const val BT_CHUNK_DELAY_MS = 20L
    private const val BT_CLOSE_DELAY_MS = 1200L
    private const val USB_CHUNK = 4096
    private const val USB_TIMEOUT_MS = 5000
    private const val WIFI_CHUNK = 4096

    /* ===================================================================
     * BLUETOOTH (klasik / SPP) - printer harus sudah di-pair di HP
     * =================================================================== */

    @SuppressLint("MissingPermission")
    fun bondedBluetoothDevices(ctx: Context): List<BtDevice> {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            ?: return emptyList()
        return try {
            adapter.bondedDevices
                .map { BtDevice(it.name ?: "(tanpa nama)", it.address) }
                .sortedBy { it.name.lowercase() }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun sendBluetooth(ctx: Context, address: String, data: ByteArray) =
        withContext(Dispatchers.IO) {
            val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
                ?: throw PrintException("Perangkat ini tidak mendukung Bluetooth.")
            if (!adapter.isEnabled) throw PrintException("Bluetooth belum aktif. Nyalakan Bluetooth terlebih dulu.")

            val device = try {
                adapter.getRemoteDevice(address)
            } catch (e: IllegalArgumentException) {
                throw PrintException("Alamat printer Bluetooth tidak valid. Pilih ulang printer.")
            }
            adapter.cancelDiscovery()

            var socket: BluetoothSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            try {
                socket.connect()
            } catch (first: IOException) {
                try {
                    socket.close()
                } catch (ignored: IOException) {
                }
                // Cadangan untuk printer murah yang tidak mengiklankan UUID SPP dengan benar
                try {
                    socket = device.javaClass
                        .getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        .invoke(device, 1) as BluetoothSocket
                    socket.connect()
                } catch (second: Exception) {
                    try {
                        socket.close()
                    } catch (ignored: IOException) {
                    }
                    throw PrintException(
                        "Tidak bisa terhubung ke printer. Pastikan printer menyala, berada dekat, " +
                            "dan tidak sedang dipakai perangkat lain."
                    )
                }
            }

            try {
                val out = socket.outputStream
                var off = 0
                while (off < data.size) {
                    val len = minOf(BT_CHUNK, data.size - off)
                    out.write(data, off, len)
                    out.flush()
                    off += len
                    delay(BT_CHUNK_DELAY_MS)
                }
                delay(BT_CLOSE_DELAY_MS) // beri waktu printer menerima sisa data sebelum koneksi ditutup
            } finally {
                try {
                    socket.close()
                } catch (ignored: IOException) {
                }
            }
        }

    /* ===================================================================
     * USB (kabel OTG) - USB Host API
     * =================================================================== */

    private fun hasBulkOut(dev: UsbDevice): Boolean {
        for (i in 0 until dev.interfaceCount) {
            val itf = dev.getInterface(i)
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.direction == UsbConstants.USB_DIR_OUT && ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) return true
            }
        }
        return false
    }

    private fun isPrinterClass(dev: UsbDevice): Boolean {
        for (i in 0 until dev.interfaceCount) {
            if (dev.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_PRINTER) return true
        }
        return false
    }

    /** Perangkat USB yang bisa dipakai mencetak (printer didahulukan). */
    fun usbCandidates(ctx: Context): List<UsbDevice> {
        val usb = ctx.getSystemService(Context.USB_SERVICE) as? UsbManager ?: return emptyList()
        return usb.deviceList.values
            .filter { hasBulkOut(it) }
            .sortedByDescending { isPrinterClass(it) }
    }

    fun usbLabel(dev: UsbDevice): String {
        val rawName: String? = try {
            dev.productName
        } catch (e: Exception) {
            null
        }
        val name = rawName ?: "Perangkat USB"
        val ids = String.format("%04X:%04X", dev.vendorId, dev.productId)
        val tag = if (isPrinterClass(dev)) "printer" else "bukan kelas printer"
        return "$name ($ids, $tag)"
    }

    private suspend fun requestUsbPermission(app: Context, usb: UsbManager, dev: UsbDevice): Boolean =
        suspendCancellableCoroutine { cont ->
            val action = app.packageName + ".USB_PERMISSION"
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    try {
                        app.unregisterReceiver(this)
                    } catch (ignored: Exception) {
                    }
                    if (cont.isActive) {
                        cont.resume(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                    }
                }
            }
            ContextCompat.registerReceiver(app, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(app, 0, Intent(action).setPackage(app.packageName), flags)
            cont.invokeOnCancellation {
                try {
                    app.unregisterReceiver(receiver)
                } catch (ignored: Exception) {
                }
            }
            usb.requestPermission(dev, pi)
        }

    suspend fun sendUsb(ctx: Context, data: ByteArray) = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        val usb = app.getSystemService(Context.USB_SERVICE) as? UsbManager
            ?: throw PrintException("Perangkat ini tidak mendukung USB Host (OTG).")
        val dev = usbCandidates(app).firstOrNull()
            ?: throw PrintException(
                "Printer USB tidak ditemukan. Sambungkan printer dengan kabel USB OTG, " +
                    "nyalakan printer, lalu coba lagi."
            )

        if (!usb.hasPermission(dev)) {
            val granted = requestUsbPermission(app, usb, dev)
            if (!granted) throw PrintException("Izin akses USB ditolak.")
        }

        val conn = usb.openDevice(dev) ?: throw PrintException("Gagal membuka perangkat USB.")
        try {
            var chosenItf: UsbInterface? = null
            var chosenEp: UsbEndpoint? = null
            for (pass in 0..1) { // pass 0: antarmuka kelas printer, pass 1: antarmuka apa pun yang punya bulk OUT
                for (i in 0 until dev.interfaceCount) {
                    val itf = dev.getInterface(i)
                    if (pass == 0 && itf.interfaceClass != UsbConstants.USB_CLASS_PRINTER) continue
                    for (e in 0 until itf.endpointCount) {
                        val ep = itf.getEndpoint(e)
                        if (ep.direction == UsbConstants.USB_DIR_OUT && ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            chosenItf = itf
                            chosenEp = ep
                            break
                        }
                    }
                    if (chosenEp != null) break
                }
                if (chosenEp != null) break
            }
            val itf = chosenItf ?: throw PrintException("Endpoint cetak USB tidak ditemukan.")
            val ep = chosenEp ?: throw PrintException("Endpoint cetak USB tidak ditemukan.")

            if (!conn.claimInterface(itf, true)) throw PrintException("Gagal mengambil alih antarmuka USB printer.")
            try {
                var off = 0
                while (off < data.size) {
                    val len = minOf(USB_CHUNK, data.size - off)
                    val n = conn.bulkTransfer(ep, data, off, len, USB_TIMEOUT_MS)
                    if (n <= 0) throw PrintException("Gagal mengirim data ke printer USB (cek kabel & printer).")
                    off += n
                }
            } finally {
                conn.releaseInterface(itf)
            }
        } finally {
            conn.close()
        }
    }

    /* ===================================================================
     * WIFI / LAN (raw TCP port 9100)
     * =================================================================== */

    suspend fun sendWifi(host: String, port: Int, data: ByteArray) = withContext(Dispatchers.IO) {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 5000)
                val out = socket.getOutputStream()
                var off = 0
                while (off < data.size) {
                    val len = minOf(WIFI_CHUNK, data.size - off)
                    out.write(data, off, len)
                    off += len
                }
                out.flush()
                delay(600)
            }
        } catch (e: IOException) {
            throw PrintException(
                "Tidak bisa terhubung ke printer WiFi $host:$port. Pastikan HP dan printer " +
                    "satu jaringan dan alamat IP benar."
            )
        }
    }
}
