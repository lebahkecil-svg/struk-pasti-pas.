package com.spbu.strukpastipas

import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream

/** Pembuat perintah ESC/POS untuk printer thermal. */
object EscPos {
    private const val RASTER_BAND_ROWS = 128
    private const val FEED_LINES = 4

    /** Ambang kehitaman (0-255). Piksel dengan kecerahan di bawah ini dicetak hitam. */
    private const val THRESHOLD = 170

    private fun initCmd() = byteArrayOf(0x1B, 0x40)

    private fun feedAndCut(out: ByteArrayOutputStream) {
        out.write(byteArrayOf(0x1B, 0x64, FEED_LINES.toByte())) // ESC d n : feed n baris
        out.write(byteArrayOf(0x1D, 0x56, 0x01))                // GS V 1   : potong (partial)
    }

    /** Mode GAMBAR: bitmap struk dikirim sebagai raster (GS v 0). Hasil = identik dengan pratinjau. */
    fun imageJob(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(initCmd())
        out.write(bitmapToRaster(bmp))
        feedAndCut(out)
        return out.toByteArray()
    }

    /** Mode TEKS: memakai font bawaan printer (sama dengan format RawBT di versi HTML). */
    fun textJob(text: String): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(initCmd())
        out.write(text.toByteArray(Charsets.UTF_8))
        out.write(byteArrayOf(0x1D, 0x56, 0x01))
        return out.toByteArray()
    }

    private fun bitmapToRaster(bmp: Bitmap): ByteArray {
        val w = bmp.width
        val h = bmp.height
        val wBytes = (w + 7) / 8
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val out = ByteArrayOutputStream()
        var y0 = 0
        while (y0 < h) {
            val rows = minOf(RASTER_BAND_ROWS, h - y0)
            // GS v 0 m xL xH yL yH d1...dk
            out.write(
                byteArrayOf(
                    0x1D, 0x76, 0x30, 0x00,
                    (wBytes and 0xFF).toByte(), ((wBytes shr 8) and 0xFF).toByte(),
                    (rows and 0xFF).toByte(), ((rows shr 8) and 0xFF).toByte()
                )
            )
            val buf = ByteArray(wBytes * rows)
            for (r in 0 until rows) {
                val rowOffset = (y0 + r) * w
                for (x in 0 until w) {
                    val px = pixels[rowOffset + x]
                    val lum = (0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)).toInt()
                    if (lum < THRESHOLD) {
                        val idx = r * wBytes + (x shr 3)
                        buf[idx] = (buf[idx].toInt() or (0x80 shr (x and 7))).toByte()
                    }
                }
            }
            out.write(buf)
            y0 += rows
        }
        return out.toByteArray()
    }
}
