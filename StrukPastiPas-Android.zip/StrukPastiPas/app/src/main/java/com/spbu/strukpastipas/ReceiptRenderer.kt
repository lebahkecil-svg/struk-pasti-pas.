package com.spbu.strukpastipas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Menggambar struk menjadi Bitmap.
 *
 * Seluruh ukuran di bawah memakai satuan "px CSS" dari versi HTML (lebar struk 302px,
 * padding 16/14/20, font monospace 12.5px, tinggi baris 1.5, label 118px, dst), lalu
 * dikalikan faktor skala sesuai lebar bitmap. Bitmap yang sama dipakai untuk pratinjau
 * di layar DAN untuk dicetak, jadi hasil cetak selalu sama persis dengan tampilan.
 */
object ReceiptRenderer {
    const val DESIGN_WIDTH = 302f

    /**
     * Lebar kolom label (px CSS). Nilai 118 sama persis dengan versi HTML, sehingga label panjang
     * ("Harga Non Subsidi", "Subsidi Pemerintah") tampil menempel/menabrak titik dua seperti aslinya.
     * Ubah ke 136f bila ingin label panjang tidak bertabrakan.
     */
    const val LABEL_WIDTH = 118f

    private const val PAD_X = 14f
    private const val PAD_TOP = 16f
    private const val PAD_BOTTOM = 20f
    private const val COLON_WIDTH = 12f
    private const val BASE_SIZE = 12.5f
    private const val LINE_FACTOR = 1.5f
    private const val LOGO_WIDTH = 150f
    private const val SEP_MARGIN = 8f
    private const val LOGO_MARGIN_BOTTOM = 8f

    private val INK = Color.rgb(0x11, 0x11, 0x11)
    private val SEP_COLOR = Color.rgb(0x44, 0x44, 0x44)
    private val regularTf: Typeface = Typeface.MONOSPACE
    private val boldTf: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    @Volatile
    private var logoCache: Bitmap? = null

    private fun logo(ctx: Context): Bitmap {
        logoCache?.let { return it }
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val b = BitmapFactory.decodeResource(ctx.applicationContext.resources, R.drawable.pertamina_logo, opts)
        logoCache = b
        return b
    }

    private fun textPaint(sizePx: Float, bold: Boolean): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = INK
            typeface = if (bold) boldTf else regularTf
            textSize = sizePx
        }

    /** Pemenggalan baris per kata (seperti wrap di browser). */
    private fun wrap(text: String, paint: Paint, maxW: Float): List<String> {
        if (text.isEmpty()) return listOf("")
        val out = ArrayList<String>()
        for (para in text.split("\n")) {
            var cur = ""
            for (word in para.split(" ")) {
                val cand = if (cur.isEmpty()) word else "$cur $word"
                if (paint.measureText(cand) <= maxW) {
                    cur = cand
                } else {
                    if (cur.isNotEmpty()) {
                        out.add(cur)
                        cur = ""
                    }
                    var w = word
                    while (w.length > 1 && paint.measureText(w) > maxW) {
                        var n = w.length
                        while (n > 1 && paint.measureText(w, 0, n) > maxW) n--
                        out.add(w.substring(0, n))
                        w = w.substring(n)
                    }
                    cur = w
                }
            }
            out.add(cur)
        }
        return out
    }

    /** Membuat bitmap struk dengan lebar [widthPx] piksel (tinggi menyesuaikan isi). */
    fun render(ctx: Context, lines: List<RLine>, widthPx: Int): Bitmap {
        val logo = logo(ctx)
        val s = widthPx / DESIGN_WIDTH
        val hCss = layoutAndDraw(logo, lines, s, null)
        val hPx = Math.ceil((hCss * s).toDouble()).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(widthPx, hPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        layoutAndDraw(logo, lines, s, canvas)
        return bmp
    }

    /**
     * Menghitung tata letak sekaligus menggambar (bila [canvas] tidak null).
     * Margin vertikal antar elemen digabung (collapse) seperti CSS.
     * @return tinggi total dalam px CSS
     */
    private fun layoutAndDraw(logo: Bitmap, lines: List<RLine>, s: Float, canvas: Canvas?): Float {
        val contentW = DESIGN_WIDTH - 2 * PAD_X
        val lineH = BASE_SIZE * LINE_FACTOR
        val logoH = LOGO_WIDTH * logo.height / logo.width

        val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val sepPaint = Paint().apply {
            color = SEP_COLOR
            style = Paint.Style.STROKE
            strokeWidth = s
            pathEffect = DashPathEffect(floatArrayOf(3f * s, 3f * s), 0f)
        }
        val base = textPaint(BASE_SIZE * s, false)
        val baseBold = textPaint(BASE_SIZE * s, true)

        fun baseline(paint: Paint, top: Float, lh: Float): Float {
            val fm = paint.fontMetrics
            val a = -fm.ascent
            val d = fm.descent
            return top * s + (lh * s - (a + d)) / 2f + a
        }

        var y = PAD_TOP
        var prevMb = 0f

        for (ln in lines) {
            when (ln) {
                is RLine.Logo -> {
                    y += prevMb
                    if (canvas != null) {
                        val left = (PAD_X + (contentW - LOGO_WIDTH) / 2f) * s
                        val dst = RectF(left, y * s, left + LOGO_WIDTH * s, (y + logoH) * s)
                        canvas.drawBitmap(logo, null, dst, bitmapPaint)
                    }
                    y += logoH
                    prevMb = LOGO_MARGIN_BOTTOM
                }

                is RLine.Sep -> {
                    y += maxOf(prevMb, SEP_MARGIN)
                    if (canvas != null) {
                        val ly = (y + 0.5f) * s
                        canvas.drawLine(PAD_X * s, ly, (DESIGN_WIDTH - PAD_X) * s, ly, sepPaint)
                    }
                    y += 1f
                    prevMb = SEP_MARGIN
                }

                is RLine.Block -> {
                    val p = textPaint(ln.size * s, ln.bold)
                    val wrapped = wrap(ln.text, p, contentW * s)
                    val lh = ln.size * LINE_FACTOR
                    y += maxOf(prevMb, ln.mt)
                    if (canvas != null) {
                        for ((i, text) in wrapped.withIndex()) {
                            val top = y + i * lh
                            val bl = baseline(p, top, lh)
                            val x = if (ln.center) {
                                PAD_X * s + (contentW * s - p.measureText(text)) / 2f
                            } else {
                                PAD_X * s
                            }
                            canvas.drawText(text, x, bl, p)
                        }
                    }
                    y += lh * wrapped.size
                    prevMb = ln.mb
                }

                is RLine.Row -> {
                    y += prevMb
                    if (canvas != null) {
                        val bl = baseline(base, y, lineH)
                        canvas.drawText(ln.label, PAD_X * s, bl, base)
                        canvas.drawText(":", (PAD_X + LABEL_WIDTH) * s, bl, base)
                        canvas.drawText(ln.value, (PAD_X + LABEL_WIDTH + COLON_WIDTH) * s, bl, base)
                    }
                    y += lineH
                    prevMb = 0f
                }

                is RLine.Total -> {
                    y += prevMb
                    if (canvas != null) {
                        val bl = baseline(baseBold, y, lineH)
                        val x = (DESIGN_WIDTH - PAD_X) * s - baseBold.measureText(ln.value)
                        canvas.drawText(ln.value, x, bl, baseBold)
                    }
                    y += lineH
                    prevMb = 0f
                }
            }
        }
        return y + prevMb + PAD_BOTTOM
    }
}
