package com.spbu.strukpastipas

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF0A4F8C)
val AccentDark = Color(0xFF083D6E)
val PageBg = Color(0xFFE8E8EC)
val FieldBorder = Color(0xFFCCCCCC)
val FieldDisabledBg = Color(0xFFF2F4F7)
val LabelColor = Color(0xFF444444)
val NoteColor = Color(0xFF888888)
val OkGreen = Color(0xFF1D8F4A)
val ErrorRed = Color(0xFFC62828)
val PanelBg = Color(0xFFF5F7FA)
val PanelBorder = Color(0xFFDDE3EA)
val SecondaryBg = Color(0xFFEEF4FB)

@Composable
fun StrukTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            background = PageBg,
            surface = Color.White
        ),
        content = content
    )
}
