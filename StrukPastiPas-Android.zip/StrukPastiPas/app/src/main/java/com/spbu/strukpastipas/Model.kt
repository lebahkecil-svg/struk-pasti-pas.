package com.spbu.strukpastipas

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Harga per liter satu jenis BBM. */
data class Price(val nonSubsidi: Double, val subsidi: Double)

/** Semua nilai bawaan (sama dengan versi HTML). Ubah di sini bila perlu. */
object Config {
    val JENIS_LIST = listOf("PERTAMINA DEX", "PERTAMAX TURBO", "PERTALITE", "PERTAMAX GREEN", "PERTAMAX")

    /** Jenis BBM bersubsidi -> memakai struk panjang. Selain itu -> struk pendek. */
    val JENIS_SUBSIDI = setOf("PERTALITE")

    val SHIFTS = listOf("1", "2", "3")
    val POMPA = (1..10).map { it.toString() }

    val OPERATORS = listOf(
        "CHAIRUL IMAM",
        "DEBY HERDIANSYAH",
        "EKA AYU PERMATA SARI",
        "FALAH SHOFWANSYAH",
        "FAWWAZ AUFA NUROHIM",
        "LAURA FIRNANDA AURORA",
        "LUTFI DWI ARIANTO",
        "LUTFI NIZAL RAMADHAN",
        "MUHAMMAD SADEWO",
        "MUHAROM NURFADLI",
        "MULYANA KUMBARA",
        "NADILLA OCTAVIA PUTRI",
        "RANGGA ADITIA",
        "REGINA REFIANA",
        "ZAHRA NAFILAH"
    )

    val DEFAULT_PRICES = mapOf(
        "PERTAMINA DEX" to Price(13700.0, 0.0),
        "PERTAMAX TURBO" to Price(14400.0, 0.0),
        "PERTALITE" to Price(15898.0, 5898.0),
        "PERTAMAX GREEN" to Price(13000.0, 0.0),
        "PERTAMAX" to Price(12100.0, 0.0)
    )

    const val WAKTU_PATTERN = "dd/MM/yyyy HH:mm:ss"
}

fun isJenisSubsidi(jenis: String): Boolean = jenis in Config.JENIS_SUBSIDI

/** Setara Math.round() di JavaScript (pembulatan .5 ke atas). */
fun jsRound(n: Double): Long =
    if (n.isNaN() || n.isInfinite()) 0L else Math.floor(n + 0.5).toLong()

/** 15898 -> "15,898" (sama dengan toLocaleString('en-US') di versi HTML). */
fun fmtRupiah(n: Double): String = String.format(Locale.US, "%,d", jsRound(n))

/** 10 -> "10.000" */
fun fmtVolume(n: Double): String = String.format(Locale.US, "%.3f", n)

/** 15898.0 -> "15898", 12.5 -> "12.5" */
fun numStr(d: Double): String =
    if (!d.isNaN() && !d.isInfinite() && d == Math.floor(d)) d.toLong().toString() else d.toString()

fun formatWaktu(cal: Calendar): String =
    SimpleDateFormat(Config.WAKTU_PATTERN, Locale.US).format(cal.time)

fun formatWaktuNow(): String =
    SimpleDateFormat(Config.WAKTU_PATTERN, Locale.US).format(Date())

fun parseWaktu(s: String): Calendar? {
    return try {
        val f = SimpleDateFormat(Config.WAKTU_PATTERN, Locale.US)
        f.isLenient = false
        val d = f.parse(s.trim()) ?: return null
        Calendar.getInstance().apply { time = d }
    } catch (e: Exception) {
        null
    }
}

/** Data yang dipakai untuk membuat struk (hasil olahan dari form). */
data class ReceiptInput(
    val kodeSpbu: String,
    val namaSpbu: String,
    val alamat: String,
    val shift: String,
    val noTrans: String,
    val waktu: String,
    val pulauPompa: String,
    val operatorName: String,
    val jenisBBM: String,
    val volume: Double,
    val hargaNonSubsidi: Double,
    val subsidiLiter: Double,
    val hargaJual: Double,
    val plat: String,
    val odometer: String
) {
    val subsidi: Boolean get() = isJenisSubsidi(jenisBBM)
    val totalTanpaSubsidi: Double get() = volume * hargaNonSubsidi
    val totalSubsidi: Double get() = volume * subsidiLiter
    val totalDibayar: Double get() = volume * hargaJual
}
