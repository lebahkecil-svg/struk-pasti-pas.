package com.spbu.strukpastipas

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.print.PrintHelper
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun StrukScreen(vm: MainViewModel) {
    BoxWithConstraints(Modifier.fillMaxSize().background(PageBg)) {
        val wide = maxWidth >= 760.dp
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Form Isian Struk Pertamina",
                color = Accent,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (wide) "SPBU 31.107.02 — Samanhudi  |  Isi form di kiri, hasil cetak siap thermal 80mm di kanan"
                else "SPBU 31.107.02 — Samanhudi  |  Isi form di atas, hasil cetak siap thermal 80mm di bawah",
                color = Color(0xFF666666),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            if (wide) {
                Row(
                    Modifier.fillMaxWidth().widthIn(max = 1100.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    FormPanel(vm, Modifier.weight(1f))
                    ReceiptPanel(vm)
                }
            } else {
                FormPanel(vm, Modifier.fillMaxWidth())
                Spacer(Modifier.height(24.dp))
                ReceiptPanel(vm)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/* ======================================================================
 * PRATINJAU STRUK  (bitmap yang sama dengan yang dicetak)
 * ====================================================================== */
@Composable
fun ReceiptPanel(vm: MainViewModel) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    val input = vm.receiptInput()
    val bmp = remember(input, density) {
        ReceiptRenderer.render(
            context,
            buildReceiptLines(input),
            (ReceiptRenderer.DESIGN_WIDTH * density).roundToInt()
        )
    }
    Box(
        Modifier
            .width(302.dp)
            .shadow(6.dp)
            .background(Color.White)
    ) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = "Pratinjau struk",
            modifier = Modifier.fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height.toFloat()),
            contentScale = ContentScale.FillBounds
        )
    }
}

/* ======================================================================
 * PANEL FORM
 * ====================================================================== */
@Composable
fun FormPanel(vm: MainViewModel, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier
            .shadow(2.dp, shape)
            .background(Color.White, shape)
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        // ---------- Identitas SPBU ----------
        SectionTitle("Identitas SPBU", first = true)
        FieldLabel("Kode SPBU")
        FormInput(vm.kodeSpbu, { vm.kodeSpbu = it })
        FieldLabel("Nama SPBU")
        FormInput(vm.namaSpbu, { vm.namaSpbu = it })
        FieldLabel("Alamat")
        FormInput(vm.alamat, { vm.alamat = it })

        // ---------- Transaksi ----------
        SectionTitle("Transaksi")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                FieldLabel("Shift")
                FormDropdown(vm.shift, Config.SHIFTS, { vm.shift = it })
            }
            Column(Modifier.weight(1f)) {
                FieldLabel("No. Trans")
                FormInput(vm.noTrans, { vm.noTrans = it })
            }
        }
        WaktuField(vm)

        // ---------- Detail Pengisian ----------
        SectionTitle("Detail Pengisian")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                FieldLabel("Pulau/Pompa")
                FormDropdown(vm.pulauPompa, Config.POMPA, { vm.pulauPompa = it })
            }
            Column(Modifier.weight(1f)) {
                FieldLabel("Operator")
                FormDropdown(vm.operatorName, Config.OPERATORS, { vm.operatorName = it })
            }
        }
        FieldLabel("Jenis BBM")
        FormDropdown(vm.jenisBBM, Config.JENIS_LIST, { vm.onJenisChange(it) })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                FieldLabel("Volume (liter)")
                FormInput(vm.volume, { vm.onVolumeChange(it) }, keyboardType = KeyboardType.Decimal)
            }
            Column(Modifier.weight(1f)) {
                FieldLabel("atau Nominal Dibayar (Rp)")
                FormInput(vm.nominal, { vm.onNominalChange(it) }, keyboardType = KeyboardType.Decimal)
            }
        }
        Note("Isi salah satu saja: ketik Volume → Nominal ikut terhitung, atau ketik Nominal → Volume ikut terhitung (3 angka di belakang koma).")

        // ---------- Informasi Harga ----------
        SectionTitle("Informasi Harga BBM (Rp/Liter)")
        FieldLabel("Harga Non Subsidi")
        FormInput(numStr(vm.hargaNonSubsidi), {}, readOnly = true)
        FieldLabel("Subsidi Pemerintah (per liter)")
        FormInput(numStr(vm.subsidiLiter), {}, readOnly = true)
        FieldLabel("Harga Jual (per liter)")
        FormInput(numStr(vm.hargaJual), {}, readOnly = true)
        Note("Harga di atas otomatis mengikuti Jenis BBM yang dipilih, sesuai pengaturan harga di bawah. Total penjualan & subsidi dihitung dari Volume × harga.")

        // ---------- Pengaturan Harga ----------
        SectionTitle("Pengaturan Harga BBM per Liter")
        Text(
            buildAnnotatedString {
                append("Bagian ini ")
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("tidak ikut tercetak") }
                append(" di struk. Isi/ubah harga tiap jenis BBM di sini, lalu tekan Simpan — harga akan otomatis dipakai terus sampai diubah & disimpan lagi.")
            },
            color = NoteColor,
            fontSize = 10.5.sp,
            lineHeight = 14.sp
        )
        PriceSettings(vm)

        // ---------- Data Kendaraan ----------
        SectionTitle("Data Kendaraan")
        FieldLabel("Plat Nomor")
        FormInput(vm.plat, { vm.plat = it })
        FieldLabel("Odometer")
        FormInput(vm.odometer, { vm.odometer = it }, placeholder = "Contoh: 45231 km (opsional)")
        Note("Plat Nomor & Odometer bersifat opsional untuk struk pendek (non subsidi) — baris tidak akan tercetak bila dikosongkan. Untuk struk panjang (Pertalite/subsidi), kedua baris selalu tercetak.")

        // ---------- Cetak ----------
        PrintSection(vm)
    }
}

/* ---------------------------- Waktu ---------------------------- */
@Composable
private fun WaktuField(vm: MainViewModel) {
    val context = LocalContext.current
    FieldLabel("Waktu (tanggal & jam)")
    FormInput(vm.waktu, { vm.waktu = it }, placeholder = "dd/MM/yyyy HH:mm:ss")
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AppButton("📅 Tanggal", { pickDate(context, vm) }, Modifier.weight(1f), secondary = true, fontSize = 12.sp, vPad = 8.dp)
        AppButton("🕒 Jam", { pickTime(context, vm) }, Modifier.weight(1f), secondary = true, fontSize = 12.sp, vPad = 8.dp)
        AppButton("⏱ Sekarang", { vm.waktu = formatWaktuNow() }, Modifier.weight(1f), secondary = true, fontSize = 12.sp, vPad = 8.dp)
    }
    Note("Format: hari/bulan/tahun jam:menit:detik. Detik bisa diketik langsung.")
}

private fun pickDate(context: Context, vm: MainViewModel) {
    val cal = parseWaktu(vm.waktu) ?: Calendar.getInstance()
    DatePickerDialog(
        context,
        { _, y, m, d ->
            cal.set(Calendar.YEAR, y)
            cal.set(Calendar.MONTH, m)
            cal.set(Calendar.DAY_OF_MONTH, d)
            vm.waktu = formatWaktu(cal)
        },
        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}

private fun pickTime(context: Context, vm: MainViewModel) {
    val cal = parseWaktu(vm.waktu) ?: Calendar.getInstance()
    TimePickerDialog(
        context,
        { _, h, mi ->
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, mi)
            vm.waktu = formatWaktu(cal)
        },
        cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true
    ).show()
}

/* ---------------------------- Pengaturan harga ---------------------------- */
@Composable
private fun PriceSettings(vm: MainViewModel) {
    val smallPad = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
    Column(Modifier.fillMaxWidth()) {
        Config.JENIS_LIST.forEach { jenis ->
            val p = vm.prices[jenis] ?: Price(0.0, 0.0)
            val d = vm.priceDraft[jenis]
            val non = if (vm.editingPrices) (d?.non ?: "") else numStr(p.nonSubsidi)
            val sub = if (vm.editingPrices) (d?.sub ?: "") else numStr(p.subsidi)
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(jenis, color = LabelColor, fontSize = 11.5.sp, modifier = Modifier.width(118.dp))
                FormInput(
                    non, { vm.onDraftChange(jenis, non = it) }, Modifier.weight(1f),
                    enabled = vm.editingPrices, keyboardType = KeyboardType.Decimal,
                    placeholder = "Non Subsidi", fontSize = 12.sp, padding = smallPad
                )
                FormInput(
                    sub, { vm.onDraftChange(jenis, sub = it) }, Modifier.weight(1f),
                    enabled = vm.editingPrices, keyboardType = KeyboardType.Decimal,
                    placeholder = "Subsidi", fontSize = 12.sp, padding = smallPad
                )
            }
        }
        if (vm.editingPrices) {
            AppButton("💾 Simpan Harga", { vm.savePrices() }, Modifier.padding(top = 10.dp))
        } else {
            AppButton("✏️ Edit Harga", { vm.startEditPrices() }, Modifier.padding(top = 10.dp), secondary = true)
        }
        if (vm.priceSaved) {
            Text(
                "✅ Harga tersimpan & sedang dipakai.",
                color = OkGreen,
                fontSize = 10.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

/* ======================================================================
 * CETAK: Bluetooth / USB / WiFi + Layanan Cetak Android
 * ====================================================================== */
@Composable
private fun PrintSection(vm: MainViewModel) {
    val context = LocalContext.current
    var showBtDialog by remember { mutableStateOf(false) }
    val pending = remember { mutableStateOf<(() -> Unit)?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val action = pending.value
        pending.value = null
        if (granted) {
            action?.invoke()
        } else {
            vm.setStatus("⚠️ Izin Bluetooth ditolak. Aktifkan izin \"Perangkat di sekitar\" untuk aplikasi ini di Pengaturan Android.", true)
        }
    }

    fun withBluetoothPermission(action: () -> Unit) {
        val needs = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        if (needs) {
            pending.value = action
            permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            action()
        }
    }

    LaunchedEffect(Unit) { vm.scanUsb() }

    Column(Modifier.fillMaxWidth().padding(top = 22.dp)) {
        FieldLabel("Koneksi Printer Thermal")
        ChipRow {
            ChoiceChip("🔵 Bluetooth", vm.connType == ConnType.BLUETOOTH, { vm.updateConnType(ConnType.BLUETOOTH) }, Modifier.weight(1f))
            ChoiceChip("🔌 USB", vm.connType == ConnType.USB, { vm.updateConnType(ConnType.USB) }, Modifier.weight(1f))
            ChoiceChip("📶 WiFi", vm.connType == ConnType.WIFI, { vm.updateConnType(ConnType.WIFI) }, Modifier.weight(1f))
        }

        // ---- Panel pengaturan (gaya sama dengan panel WiFi di versi HTML) ----
        val panelShape = RoundedCornerShape(8.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .background(PanelBg, panelShape)
                .border(1.dp, PanelBorder, panelShape)
                .padding(12.dp)
        ) {
            when (vm.connType) {
                ConnType.BLUETOOTH -> {
                    Text("Printer terpilih", color = LabelColor, fontSize = 12.sp)
                    Text(
                        if (vm.btAddress.isBlank()) "(belum dipilih)" else vm.btName + "\n" + vm.btAddress,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFF222222),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    AppButton(
                        "🔵 Pilih Printer Bluetooth",
                        { withBluetoothPermission { vm.loadBtDevices(); showBtDialog = true } },
                        Modifier.padding(top = 10.dp),
                        secondary = true
                    )
                    PanelNote("Pasangkan (pair) printer lebih dulu di Pengaturan Bluetooth Android (PIN umumnya 0000 atau 1234), lalu pilih di sini. Data dikirim langsung ke printer tanpa aplikasi tambahan.")
                }

                ConnType.USB -> {
                    Text("Printer USB terdeteksi", color = LabelColor, fontSize = 12.sp)
                    if (vm.usbLabels.isEmpty()) {
                        Text(
                            "(tidak ada)",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = Color(0xFF222222),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    } else {
                        vm.usbLabels.forEach {
                            Text(
                                it,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = Color(0xFF222222),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                    AppButton("🔄 Cari Printer USB", { vm.scanUsb() }, Modifier.padding(top = 10.dp), secondary = true)
                    PanelNote("Sambungkan printer ke HP dengan kabel USB (pakai adaptor OTG bila perlu), nyalakan printer, lalu tekan Cari Printer USB. Saat mencetak pertama kali, izinkan akses USB ketika diminta.")
                }

                ConnType.WIFI -> {
                    FieldLabel("Alamat IP Printer")
                    FormInput(
                        vm.wifiHost, { vm.updateWifiHost(it) },
                        keyboardType = KeyboardType.Uri, placeholder = "Contoh: 192.168.1.50"
                    )
                    FieldLabel("Port")
                    FormInput(vm.wifiPort, { vm.updateWifiPort(it) }, keyboardType = KeyboardType.Number, placeholder = "9100")
                    PanelNote("HP dan printer harus berada di jaringan WiFi/LAN yang sama. Alamat IP biasanya tercetak saat self-test printer. Port standar printer thermal adalah 9100.")
                }
            }

            FieldLabel("Lebar kertas")
            ChipRow {
                ChoiceChip("58 mm", vm.paperMm == 58, { vm.updatePaperMm(58) }, Modifier.weight(1f))
                ChoiceChip("80 mm", vm.paperMm == 80, { vm.updatePaperMm(80) }, Modifier.weight(1f))
            }
            FieldLabel("Mode cetak")
            ChipRow {
                ChoiceChip("🖼 Gambar", vm.printMode == PrintMode.IMAGE, { vm.updatePrintMode(PrintMode.IMAGE) }, Modifier.weight(1f))
                ChoiceChip("🔤 Teks", vm.printMode == PrintMode.TEXT, { vm.updatePrintMode(PrintMode.TEXT) }, Modifier.weight(1f))
            }
            PanelNote(
                if (vm.printMode == PrintMode.IMAGE) {
                    "Gambar: hasil cetak sama persis dengan pratinjau struk (termasuk logo Pertamina)."
                } else {
                    "Teks: lebih cepat, memakai font bawaan printer (logo diganti tulisan PERTAMINA)."
                }
            )
        }

        val label = when (vm.connType) {
            ConnType.BLUETOOTH -> "🖨️ Cetak via Bluetooth"
            ConnType.USB -> "🖨️ Cetak via Kabel USB"
            ConnType.WIFI -> "🖨️ Cetak via WiFi"
        }
        AppButton(
            if (vm.printing) "Mencetak…" else label,
            {
                if (vm.connType == ConnType.BLUETOOTH) {
                    withBluetoothPermission { vm.print() }
                } else {
                    vm.print()
                }
            },
            Modifier.padding(top = 12.dp),
            enabled = !vm.printing
        )
        AppButton(
            "📄 Cetak via Layanan Cetak Android (PDF / printer lain)",
            {
                val bmp = ReceiptRenderer.render(context, buildReceiptLines(vm.receiptInput()), 1208)
                val helper = PrintHelper(context)
                helper.scaleMode = PrintHelper.SCALE_MODE_FIT
                helper.colorMode = PrintHelper.COLOR_MODE_MONOCHROME
                helper.printBitmap("Struk_" + vm.noTrans, bmp)
            },
            Modifier.padding(top = 8.dp),
            secondary = true
        )

        if (vm.status.isNotEmpty()) {
            Text(
                vm.status,
                color = if (vm.statusError) ErrorRed else OkGreen,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
        }
    }

    if (showBtDialog) {
        AlertDialog(
            onDismissRequest = { showBtDialog = false },
            title = { Text("Pilih Printer Bluetooth") },
            text = {
                if (vm.btDevices.isEmpty()) {
                    Text("Belum ada perangkat Bluetooth yang dipasangkan. Nyalakan printer, lalu pasangkan (pair) lebih dulu lewat Pengaturan Bluetooth Android.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        vm.btDevices.forEach { d ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        vm.selectBt(d)
                                        showBtDialog = false
                                    }
                                    .padding(vertical = 10.dp)
                            ) {
                                Text(d.name, fontWeight = FontWeight.Bold)
                                Text(d.address, fontSize = 12.sp, color = NoteColor, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }) { Text("Pengaturan Bluetooth") }
            },
            dismissButton = {
                TextButton(onClick = { showBtDialog = false }) { Text("Tutup") }
            }
        )
    }
}

@Composable
private fun PanelNote(text: String) {
    Text(
        text,
        color = Color(0xFF777777),
        fontSize = 11.sp,
        lineHeight = 15.sp,
        modifier = Modifier.padding(top = 8.dp)
    )
}
